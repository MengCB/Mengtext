alert( "welcome ~~~~" );

console.info("your are loding");