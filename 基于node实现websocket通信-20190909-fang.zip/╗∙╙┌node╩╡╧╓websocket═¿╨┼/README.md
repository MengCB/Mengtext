## 基于node实现websocket通信

基于node实现websocket通信
详细说明的地址：[基于node实现websocket通信](http://www.zhuyuntao.cn/2019/03/11/%E5%9F%BA%E4%BA%8Enode%E5%AE%9E%E7%8E%B0websocket%E9%80%9A%E4%BF%A1/)。

## 环境启动

### 安装依赖
当前目录下：
```
npm ci (推荐) 或 npm i
```

### 启动服务器
当前目录下：
```
npm run start
```

### 前端访问
当前目录启动 http-server 或直接打开 index.html  
看到浏览器控制台或后端控制台，可以看到已经连接成功。  


